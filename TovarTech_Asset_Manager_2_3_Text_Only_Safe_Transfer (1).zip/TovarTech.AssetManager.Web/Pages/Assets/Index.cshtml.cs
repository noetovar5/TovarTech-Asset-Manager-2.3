using Microsoft.AspNetCore.Mvc;using Microsoft.AspNetCore.Mvc.RazorPages;
namespace TovarTech.AssetManager.Web.Pages.Assets;
public class IndexModel(AssetRepository repo):PageModel{
 public List<Asset> Items {get;private set;}=[];[BindProperty(SupportsGet=true)]public string? Q{get;set;}public string? Error{get;private set;}
 public async Task OnGetAsync(){try{Items=await repo.ListAsync(Q);}catch(Exception){Error="Unable to load assets. Check SQL connectivity.";}}
 public async Task<IActionResult> OnPostDeleteAsync(int id){await repo.DeleteAsync(id);return RedirectToPage();}
}
