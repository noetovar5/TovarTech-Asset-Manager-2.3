using Microsoft.AspNetCore.Mvc;using Microsoft.AspNetCore.Mvc.RazorPages;
namespace TovarTech.AssetManager.Web.Pages.Assets;
public class EditModel(AssetRepository repo):PageModel{
 [BindProperty]public Asset Asset{get;set;}=new();
 public async Task<IActionResult> OnGetAsync(int? id){if(id.HasValue){var a=await repo.GetAsync(id.Value);if(a==null)return NotFound();Asset=a;}return Page();}
 public async Task<IActionResult> OnPostAsync(){if(!ModelState.IsValid)return Page();await repo.SaveAsync(Asset);return RedirectToPage("/Assets/Index");}
}
