using Microsoft.AspNetCore.Mvc.RazorPages;
namespace TovarTech.AssetManager.Web.Pages;
public class IndexModel(AssetRepository repo):PageModel {
 public int Total {get;private set;} public int Active {get;private set;} public int Servers {get;private set;} public int Attention {get;private set;}
 public List<Asset> Recent {get;private set;}=[];
 public List<Asset> Infrastructure {get;private set;}=[];
 public List<(string Name,int Count,string Color)> Distribution {get;private set;}=[];
 public string? Error {get;private set;}
 public async Task OnGetAsync(){
  try {
   var all=await repo.ListAsync(); Total=all.Count;
   Active=all.Count(a=>a.Status.Equals("Active",StringComparison.OrdinalIgnoreCase));
   Servers=all.Count(a=>IsServer(a.AssetType));
   Attention=all.Count(a=>!a.Status.Equals("Active",StringComparison.OrdinalIgnoreCase));
   Recent=all.Take(8).ToList(); Infrastructure=all.Where(a=>IsServer(a.AssetType)).Take(6).ToList();
   int laptop=all.Count(a=>Contains(a.AssetType,"laptop")||Contains(a.AssetType,"desktop")||Contains(a.AssetType,"workstation"));
   int server=all.Count(a=>IsServer(a.AssetType));
   int network=all.Count(a=>Contains(a.AssetType,"network")||Contains(a.AssetType,"router")||Contains(a.AssetType,"switch")||Contains(a.AssetType,"firewall"));
   Distribution=[("Workstations",laptop,"#25a5ff"),("Servers & VMs",server,"#46e2ed"),("Networking",network,"#21d9a2"),("Other",Math.Max(0,Total-laptop-server-network),"#8295bf")];
  } catch(Exception) {Error="Cannot connect to SQL Server. Check the instance, database, and Windows Authentication permissions.";}
 }
 private static bool Contains(string? value,string term)=>(value??"").Contains(term,StringComparison.OrdinalIgnoreCase);
 private static bool IsServer(string? value)=>Contains(value,"server")||Contains(value,"vm")||Contains(value,"virtual")||Contains(value,"hypervisor")||Contains(value,"proxmox")||Contains(value,"esxi");
}
