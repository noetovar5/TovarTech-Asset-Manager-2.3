// Animated counters use server-rendered values; reduced-motion users see values immediately.
(() => { if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  document.querySelectorAll('[data-counter]').forEach(el => {
    const goal = Number(el.dataset.counter); if (!Number.isFinite(goal) || goal < 1) return;
    const start = performance.now(), duration = 750;
    const tick = now => { const t = Math.min(1,(now-start)/duration); el.textContent = Math.round(goal*(1-Math.pow(1-t,3))).toLocaleString(); if(t<1)requestAnimationFrame(tick); };
    requestAnimationFrame(tick);
  });
})();
