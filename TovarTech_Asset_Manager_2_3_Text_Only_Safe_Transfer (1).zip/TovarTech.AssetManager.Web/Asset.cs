using System.ComponentModel.DataAnnotations;
namespace TovarTech.AssetManager.Web;
public class Asset {
 public int AssetId {get;set;}
 [Required, StringLength(150)] public string AssetName {get;set;}="";
 [Required, StringLength(50)] public string AssetType {get;set;}="Laptop";
 [StringLength(100)] public string Manufacturer {get;set;}="";
 [StringLength(100)] public string Model {get;set;}="";
 [StringLength(100)] public string SerialNumber {get;set;}="";
 [StringLength(150)] public string Hostname {get;set;}="";
 [StringLength(45)] public string IPAddress {get;set;}="";
 [StringLength(150)] public string OperatingSystem {get;set;}="";
 [StringLength(100)] public string Location {get;set;}="";
 [Required, RegularExpression("Active|Repair|Retired")] public string Status {get;set;}="Active";
 public string Notes {get;set;}="";
}
