# TovarTech Asset Manager 2.3 — Text-only transfer package

This archive contains **source text only**, no compiled binaries, executable installers, or images. The PowerShell build script is stored as `Build-MSI.ps1.txt` to reduce false positives from executable-script scanning. It has not been certified malware-free; scan with your security software before use.

## Restore the project
1. Extract the ZIP into a new directory.
2. In File Explorer, turn on View > Show > File name extensions. Rename `Build-MSI.ps1.txt` to `Build-MSI.ps1` after reviewing the script.
3. Copy your own trusted `tovartech-logo.png` into `TovarTech.AssetManager.Web\wwwroot\images\` (this archive omits the PNG intentionally).
4. Compare this source with the currently working project on your Windows computer before replacing any working files.

## Future build workstation requirements
- Windows 11 or Windows Server (x64)
- .NET 10 SDK (x64): https://dotnet.microsoft.com/download/dotnet/10.0
- WiX Toolset CLI: run `dotnet tool install --global wix` in PowerShell (or `dotnet tool update --global wix` if already installed).
- Git for Windows (for GitHub): https://git-scm.com/downloads/win
- Optional: Visual Studio Code: https://code.visualstudio.com/
- Internet connectivity to restore NuGet dependencies.

## Build
Open PowerShell in the extracted project folder:

```powershell
dotnet --info
wix --version
dotnet restore .\TovarTech.AssetManager.Web\TovarTech.AssetManager.Web.csproj
dotnet list .\TovarTech.AssetManager.Web\TovarTech.AssetManager.Web.csproj package --vulnerable --include-transitive
dotnet build .\TovarTech.AssetManager.Web\TovarTech.AssetManager.Web.csproj -c Release
powershell -ExecutionPolicy Bypass -File .\Build-MSI.ps1
```

MSI output: `output\TovarTech_Asset_Manager_Web_2.3.0_x64.msi`. Do not deploy until the audit and build are clean.

## Deploy to a separate Windows Server
1. Install IIS with ASP.NET Core support and the matching .NET 10 ASP.NET Core Hosting Bundle: https://dotnet.microsoft.com/download/dotnet/10.0
2. Install or connect to SQL Server/SQL Server Express, provision the application database and a least-privileged application identity. The source archive does **not** include database schema, migration scripts or production data.
3. Install the locally built MSI to stage files in Program Files. It does not automatically configure IIS or SQL Server.
4. Configure an IIS site/application pool with **No Managed Code**, a suitable identity, and point its physical path to the staged files (or a controlled deployment copy). Grant only necessary folder permissions.
5. Configure connection strings using secure server-specific configuration; do not commit credentials to GitHub. Confirm TLS and SQL permissions.
6. Verify the site and asset workflows using sample data before recording a tutorial.

## GitHub hygiene
Do not commit `bin/`, `obj/`, `publish/`, `output/`, `.vs/`, secrets, database backups, or production configuration. Upload source, docs and the build script after validation. Use GitHub Releases for a tested MSI.

## Security note
An antivirus detection is not proof of malware or of a false positive. Do not disable Defender or bypass security controls. Inspect the detection name and scan the archive. If flagged again, share the detection name and file path for investigation.
